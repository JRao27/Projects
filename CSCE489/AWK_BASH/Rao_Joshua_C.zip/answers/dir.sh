for i in 1;
do
  echo "$(ls)" > "dir.txt"
done